import { config } from 'dotenv';
config();

import '@/ai/flows/ai-symptom-assessment.ts';
import '@/ai/flows/ai-suggest-treatment-actions.ts';